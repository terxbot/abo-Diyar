<p align='center'>
  <b>🎨 Follow me here 🎨</b><br>  
  <a href="https://discord.gg/kaneki">Discord</a> |
  <a href="https://www.youtube.com/channel/UC-XII5SSqbMOF1UX3N0Gl8g">YouTube</a> |
  <a href="https://github.com/KanekiWeb">Github</a><br><br>
  <img src="https://repository-images.githubusercontent.com/415421595/c116844b-4471-4865-b26f-88a4ec2ee8cb" style="width: 80%">
</p>

##   

### 🧰 Support
- Email: <kaneki_pro@protonmail.com>
- Discord: https://discord.gg/JuEeGweHrb

##  

### 📜 License & Warning
- Make for education propose only !
- Under licensed MIT MIT License.

##  

<p align="center">
  <img src="https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat" alt="Contribution Welcome">
  <img src="https://img.shields.io/badge/License-GPLv3-blue.svg" alt="License Badge">
  <img src="https://badges.frapsoft.com/os/v3/open-source.svg?v=103" alt="Open Source">
  <img src="https://visitor-badge.laobi.icu/badge?page_id=KanekiWeb.My-Website" alt="Visitor Count">
</p>
